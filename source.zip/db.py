from flask_sqlalchemy import SQLAlchemy

# Connection with SQL database
db = SQLAlchemy()
